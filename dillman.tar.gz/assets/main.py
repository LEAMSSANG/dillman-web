print("🎮 main started")
print("📖 story:", story_texts)

# -*- coding: utf-8 -*-
import pygame

import os

def load_story(filename=os.path.join("data", "story.txt")):
    with open(filename, encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

story_texts = load_story()

import sys
import random

pygame.init()

WIDTH, HEIGHT = 800, 600
TILE_SIZE = 40
COLUMNS = WIDTH // TILE_SIZE
ROWS = HEIGHT // TILE_SIZE

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("드릴맨: 꼬순이의 대모험")

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
COPPER = (184, 115, 51)
SILVER = (192, 192, 192)
GOLD = (255, 215, 0)
RUBY = (224, 17, 95)
DIAMOND = (135, 206, 235)

clock = pygame.time.Clock()
FPS = 60

font = pygame.font.SysFont("malgungothic", 28)

kosooni_img = pygame.image.load("data/kosooni_character_40x40.png")
kosooni_img = pygame.transform.scale(kosooni_img, (80, 80))

start_button = pygame.Rect(WIDTH//2 - 100, 350, 200, 60)

def draw_main_menu():
    screen.fill(BLACK)
    title = font.render("드릴맨: 꼬순이의 대모험", True, WHITE)
    screen.blit(title, (WIDTH//2 - title.get_width()//2, 100))
    screen.blit(kosooni_img, (WIDTH//2 - 40, 150))
    pygame.draw.rect(screen, GRAY, start_button)
    label = font.render("게임 시작", True, WHITE)
    screen.blit(label, (start_button.x + start_button.width//2 - label.get_width()//2, start_button.y + 15))
    pygame.display.flip()

def show_story():
    story_texts = [
        "옛날 옛적, 고구마 왕국이 존재했어요...",
        "인간 황제는 고구마 맛탕을 혼자 먹고 싶었죠...",
        "그래서 대마법사를 시켜 고구마 왕국을 지하로 워프시켰어요...",
        "하지만 그는 죽기 전, 유물을 남겼고...",
        "그 유물이 바로 꼬순이의 삑삑이 공이었던 거죠!",
        "꼬순이는 이제, 전설의 고구마 왕국을 찾아 모험을 떠납니다!"
    ]
    idx = 0
    while True:
        screen.fill(BLACK)
        text = font.render(story_texts[idx], True, WHITE)
        screen.blit(text, (WIDTH//2 - text.get_width()//2, HEIGHT//2))
        info = font.render("클릭해서 다음으로... (ESC로 스킵)", True, GRAY)
        screen.blit(info, (WIDTH//2 - info.get_width()//2, HEIGHT - 50))
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return
            elif event.type == pygame.MOUSEBUTTONDOWN:
                idx += 1
                if idx >= len(story_texts):
                    return

def main_menu():
    while True:
        draw_main_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos):
                    show_story()
                    return

main_menu()

player = pygame.Rect(WIDTH//2 - TILE_SIZE//2, 0, TILE_SIZE, TILE_SIZE)
player_img = pygame.image.load("data/kosooni_character_40x40.png").convert_alpha()
player_speed_y = 0
GRAVITY = 0.5
MOVE_SPEED = 5

drill_stats = {
    "durability": 100,
    "power": 1,
    "speed": 5,
    "yield_bonus": 0,
    "range": 1
}

tile_defs = {
    1: {"color": COPPER, "hp": 3},
    2: {"color": SILVER, "hp": 5},
    3: {"color": GOLD, "hp": 7},
    4: {"color": RUBY, "hp": 15},
    5: {"color": DIAMOND, "hp": 30},
}

inventory = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}

class Fragment:
    def __init__(self, x, y, mineral_type):
        self.rect = pygame.Rect(x, y, 10, 10)
        self.type = mineral_type

    def update(self, target_pos):
        dx = target_pos[0] - self.rect.x
        dy = target_pos[1] - self.rect.y
        distance = max(1, (dx**2 + dy**2) ** 0.5)
        speed = drill_stats["speed"]
        self.rect.x += int(dx / distance * speed)
        self.rect.y += int(dy / distance * speed)

mineral_effects = {
    1: lambda: drill_stats.update({"durability": drill_stats["durability"] + 10}),
    2: lambda: drill_stats.update({"speed": drill_stats["speed"] + 1}),
    3: lambda: drill_stats.update({"power": drill_stats["power"] + 1}),
    4: lambda: drill_stats.update({"yield_bonus": drill_stats["yield_bonus"] + 5}),
    5: lambda: drill_stats.update({"range": min(3, drill_stats["range"] + 1)}),
}

def generate_map(rows):
    game_map = []
    for _ in range(rows):
        row = []
        for _ in range(COLUMNS):
            block_type = random.choices([0, 1, 2, 3, 4, 5], weights=[2, 5, 4, 3, 2, 1])[0]
            if block_type == 0:
                row.append(None)
            else:
                row.append({"type": block_type, "hp": tile_defs[block_type]["hp"]})
        game_map.append(row)
    return game_map

world = generate_map(ROWS)
fragment_list = []

def drill_block(row, col):
    if 0 <= row < len(world) and 0 <= col < len(world[0]):
        tile = world[row][col]
        if tile and drill_stats["durability"] > 0:
            tile["hp"] -= drill_stats["power"]
            drill_stats["durability"] -= 1
            if tile["hp"] <= 0:
                block_type = tile["type"]
                world[row][col] = None
                fx = col * TILE_SIZE + TILE_SIZE // 2
                fy = row * TILE_SIZE + TILE_SIZE // 2
                count = 1
                if random.randint(1, 100) <= drill_stats["yield_bonus"]:
                    count += 1
                for _ in range(count):
                    fragment_list.append(Fragment(fx, fy, block_type))

def draw_inventory():
    y_offset = 10
    for t in range(1, 6):
        txt = font.render(f"x{inventory[t]}", True, WHITE)
        pygame.draw.rect(screen, tile_defs[t]["color"], (10, y_offset, 20, 20))
        screen.blit(txt, (35, y_offset))
        y_offset += 30
    stats_txt = font.render(f"DUR:{drill_stats['durability']} PWR:{drill_stats['power']} SPD:{drill_stats['speed']} RNG:{drill_stats['range']}", True, WHITE)
    screen.blit(stats_txt, (10, y_offset + 10))

running = True
while running:
    clock.tick(FPS)
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.x -= MOVE_SPEED
    if keys[pygame.K_RIGHT]:
        player.x += MOVE_SPEED

    player_speed_y += GRAVITY
    player.y += int(player_speed_y)

    row = player.y // TILE_SIZE
    col = player.x // TILE_SIZE
    if 0 <= row < ROWS and 0 <= col < COLUMNS:
        tile = world[row][col]
        if tile:
            drill_block(row, col)
            player_speed_y = -5

    for y, row_blocks in enumerate(world):
        for x, tile in enumerate(row_blocks):
            if tile:
                color = tile_defs[tile["type"]]["color"]
                pygame.draw.rect(screen, color, (x*TILE_SIZE, y*TILE_SIZE, TILE_SIZE, TILE_SIZE))

    for frag in fragment_list[:]:
        frag.update(player.center)
        pygame.draw.rect(screen, tile_defs[frag.type]["color"], frag.rect)
        if player.colliderect(frag.rect):
            inventory[frag.type] += 1
            mineral_effects[frag.type]()
            fragment_list.remove(frag)

    screen.blit(player_img, player.topleft)
    draw_inventory()
    pygame.display.flip()

pygame.quit()

import io
import builtins

builtins.open = lambda *args, **kwargs: io.open(*args, encoding='utf-8', **kwargs)

sys.exit()